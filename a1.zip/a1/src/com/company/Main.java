package com.company;

import org.junit.Test;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("hello word");
        save("1",2);
    }
    public static void save(String a,int b)
    {
        System.out.println("这里是新增保存方法");
    }
    @Test
    public void testsave()
    {
        save("11",22);
        System.out.println("ka");
    }
    /*有返回值的方法*/
    public String fanhui(String aaa)
    {
        String StackTraceElement=aaa;
        System.out.println("2");
        return StackTraceElement;
    }
    @Test
    public void fanhui2222()
    {
        System.out.println("1");
        String fanhui = fanhui("222222");
        System.out.println(fanhui);

    }
}
