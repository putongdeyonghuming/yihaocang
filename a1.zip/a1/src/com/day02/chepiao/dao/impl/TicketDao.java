package com.day02.chepiao.dao.impl;

import com.day02.chepiao.dao.ITickerDao;
import com.day02.chepiao.model.Ticket;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class TicketDao implements ITickerDao {
    @Override
    public void save(Ticket ticket) {
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
        //2.链接
            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
        //3.创建编译语句
                String sql= "insert into ticket (start_station,stop_station,start_time,ticket_price) VALUES (?,?,?,?)";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                System.out.println("语句编写完成");
                //设置参数
                preparedStatement.setString(1,ticket.getStart_station());
                preparedStatement.setString(2,ticket.getStop_station());
                preparedStatement.setString(3,ticket.getStart_time());
                preparedStatement.setInt(4,ticket.getTicket_price());
        //4.执行
                preparedStatement.executeUpdate();
        //5.关闭
                preparedStatement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("SQL写的有问题");
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("价包调用有问题");
        }


    }

    @Override
    public void delete(Integer id) {

    }

    @Override
    public void update(Ticket ticket) {

    }

    @Override
    public void queryById(Integer id) {

    }

    @Override
    public List<Ticket> queryAll() {
        return null;
    }
}
