package com.day02.chepiao.dao;

import com.day02.chepiao.model.Ticket;

import java.util.List;

public interface ITickerDao {
    //增
    public void save(Ticket ticket);
    //删
    public void delete(Integer id);
    //改
    public void update(Ticket ticket);
    //查一个
    public void queryById(Integer id);
    //查多个（用集合）多了一个list
    public List<Ticket> queryAll();
}
