package com.day02.chepiao.test;

import com.day02.chepiao.dao.impl.TicketDao;
import com.day02.chepiao.model.Ticket;
import org.junit.Test;

public class TextDao {
    @Test
    public void chepiao()
    {
        TicketDao ticketDao = new TicketDao();
        Ticket ticket = new Ticket();
        ticket.setStart_station("A");
        ticket.setStop_station("B");
        ticket.setStart_time("2021-08-22 00:00:00");
        ticket.setTicket_price(200);
        ticketDao.save(ticket);
    }
}
