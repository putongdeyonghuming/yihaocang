package com.day01.station.TestDao;

public class zi2 {
    private String zi2;
}
