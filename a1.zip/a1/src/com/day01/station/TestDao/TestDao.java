package com.day01.station.TestDao;

import com.day01.station.dao.ProducrDao;
import org.junit.Test;

public class TestDao {

    @Test
    public  void testzeng()
    {
    ProducrDao producrDao = new ProducrDao();
        producrDao.zeng();
                System.out.println("测试曾");
                }
                }
