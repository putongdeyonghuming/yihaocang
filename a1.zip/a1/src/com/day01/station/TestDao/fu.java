package com.day01.station.TestDao;

public class fu {



    private String zhujian;
    private String name;
    private String pass;

    public String getZhujian() {
        return zhujian;
    }

    public void setZhujian(String zhujian) {
        this.zhujian = zhujian;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    @Override
    public String toString() {
        return "fu{" +
                "zhujian='" + zhujian + '\'' +
                ", name='" + name + '\'' +
                ", pass='" + pass + '\'' +
                '}';
    }

    public fu() {
    }

    public fu(String zhujian, String name, String pass) {
        this.zhujian = zhujian;
        this.name = name;
        this.pass = pass;
    }
    public static void fu1() {
        System.out.println("这是父类的静态方法");
    }
    public static String a="1qwe";

    public  String getA() {
        return a;
    }

    public  void setA(String a) {
        fu.a = a;
    }
}
