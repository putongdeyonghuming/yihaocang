package com.day01.station.TestDao;

import org.junit.Test;

public class zi1 extends fu
{
    private String zi1;

    //写一个方法
    @Test
    public void  a()
    {
        com.day01.station.TestDao.zi1 zi1 = new zi1();
        zi1.setName("111");
        zi1.getName();
    }
    //静态方法可以被静态方法和非静态方法调用
    //静态方法只能调用静态方法，不能调用非静态方法
    public static void zi1()
    {
        fu1();
        System.out.println("这是子类的静态方法");
    }
    @Test
    public void b()
    {
        com.day01.station.TestDao.zi1 zi3 = new zi1();
        zi3.zi1();
    }
}
