package com.day01.station.dao.impl;

import com.day01.station.dao.a2;
import com.day01.station.model.Product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//a3实现a2的接口方法
public class a3 implements a2 {
    @Override
    public void save(String a, String b, String c){
        System.out.println("链接数据库");
        //防SQL注入
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("1.加载");
            //2.链接数据库

            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
                //3.创建编译语句发送到数据库
                //新3.创建预编译语句.下边的都不一样了
                String a4= "INSERT INTO yonghubiao(zhujian,user,pass) VALUES (?,?,?)";
                PreparedStatement preparedStatement = connection.prepareStatement(a4);
                //新3.1添加参数
                preparedStatement.setString(1,a);
                preparedStatement.setString(2,b);
                preparedStatement.setString(3,c);

                //4.执行语句、这个可以增删改，无返回值的语句
                preparedStatement.executeUpdate();

                //5.释放资源
                preparedStatement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("我猜是数据库地址写错了");
            }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("我猜是架包引用错了");
        }
    }

    @Override
    public Product query(String A1) {
        return null;
    }
}
