package com.day01.station.dao;

public class static1 {
    public static String ziduchuan ="zifuchuan";
    public static void a()
    {
        System.out.println("这是一个构造方法");
    }
}
