package com.day01.station.dao;

public class a1 {
    public Integer id;
    public  String user;
    //静态代码快，不论你创建对象几次，都执行一次
    static
    {
        System.out.println("这是静态代码块");
    }
    //构造代码块
    //每次创建对象都执行一次
    {
        System.out.println("这是构造代码块");
    }
    //构造方法
    //每次创建对象都执行一次
    public a1()
    {
        System.out.println("我是构造方法");
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
    {
        System.out.println("这是构造代码块吗");
    }
}
