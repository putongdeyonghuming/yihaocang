package com.day01.station.dao;

import com.day01.station.model.Product;
//这个是接口dao里的impala里的a3，是实现这个接口的包
public interface a2 {
    //增
    public void save(String a,String b,String c);
    //查
    public Product query(String A1);
}
