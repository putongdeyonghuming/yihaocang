package com.day01.station.dao;

import com.day01.station.TestDao.fu;
import com.day01.station.model.Product;
import org.hamcrest.Condition;
import org.junit.Test;

import java.sql.*;
public class ProducrDao {
    //增删改方法
    public void zeng()
    {
        System.out.println("链接数据库");
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("1.加载");
        //2.链接数据库

            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
                System.out.println("2");
                //3.创建编译语句发送到数据库
                Statement statement = connection.createStatement();
                System.out.println("3");
                //4.执行语句、这个可以增删改，无返回值的语句
                String a= "INSERT INTO yonghubiao(zhujian,user,pass) VALUES ('8','59279320','libin4753')";
                statement.executeUpdate(a);
                System.out.println("4");
                //5.释放资源
                statement.close();
                connection.close();
                System.out.println("5");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("我猜是数据库地址写错了");
            }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("我猜是架包引用错了");
        }
    }
    @Test
    public  void testzeng()
    {
        zeng();
        System.out.println("测试曾");

    }
    //查询方法
    public void cha()
    {
        System.out.println("链接数据库");
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("1.加载");
            //2.链接数据库

            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
                System.out.println("2");
                //3.创建编译语句发送到数据库
                Statement statement = connection.createStatement();
                System.out.println("3");
                //4.执行语句、这个可以（不能增删改）（查询），无返回值的语句
                String a= "select * from yonghubiao where zhujian='1'";
                //下边的这个和上边不一样了
                ResultSet resultSet = statement.executeQuery(a);
                //解析结果
                while (resultSet.next())
                {
                    String zhujian = resultSet.getString("zhujian");
                    String user = resultSet.getString("user");
                    String pass = resultSet.getString("pass");
                    System.out.println("zhujian="+zhujian);
                    System.out.println("user="+user);
                    System.out.println("pass"+pass);
                }
                //5.释放资源
                resultSet.close();
                statement.close();
                connection.close();
                System.out.println("5");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("我猜是数据库地址写错了");
            }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("我猜是架包引用错了");
        }
    }
    //和之前的相比，能够输入参数查询了
    public void zeng1(String zhujian, String user, String pass)//有参数的调用
    {
        System.out.println("链接数据库");
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("1.加载");
            //2.链接数据库

            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
                System.out.println("2");
                //3.创建编译语句发送到数据库
                Statement statement = connection.createStatement();
                System.out.println("3");
                //4.执行语句、这个可以增删改，无返回值的语句
                String a= "INSERT INTO yonghubiao(zhujian,user,pass) VALUES ('" + zhujian + "','" + user + "','" + pass + "')";
                statement.executeUpdate(a);
                System.out.println("4");
                //5.释放资源
                statement.close();
                connection.close();
                System.out.println("5");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("我猜是数据库地址写错了");
            }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("我猜是架包引用错了");
        }
    }
    @Test
    public void ceshi()
    {
        zeng1("6","55","555");
        cha1("6");
    }


    //查询方法,能输入参数值的
    public void cha1( String a1)
    {
        System.out.println("链接数据库");
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("1.加载");
            //2.链接数据库

            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
                System.out.println("2");
                //3.创建编译语句发送到数据库
                Statement statement = connection.createStatement();
                System.out.println("3");
                //4.执行语句、这个可以（不能增删改）（查询），无返回值的语句
                String a= "select * from yonghubiao where zhujian="+a1;
                //下边的这个和上边不一样了
                ResultSet resultSet = statement.executeQuery(a);
                //解析结果
                while (resultSet.next())
                {
                    String zhujian = resultSet.getString("zhujian");
                    String user = resultSet.getString("user");
                    String pass = resultSet.getString("pass");
                    System.out.println("zhujian="+zhujian);
                    System.out.println("user="+user);
                    System.out.println("pass"+pass);
                }
                //5.释放资源
                resultSet.close();
                statement.close();
                connection.close();
                System.out.println("5");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("我猜是数据库地址写错了");
            }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("我猜是架包引用错了");
        }
    }
    //防SQL注入的新增,JDBC
    public void zeng2(String zhujian1, String user1, String pass1)//有参数的调用
    {
        System.out.println("链接数据库");
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("1.加载");
            //2.链接数据库

            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
                //3.创建编译语句发送到数据库
                //新3.创建预编译语句.下边的都不一样了
                String a4= "INSERT INTO yonghubiao(zhujian,user,pass) VALUES (?,?,?)";
                PreparedStatement preparedStatement = connection.prepareStatement(a4);
                //新3.1添加参数
                preparedStatement.setString(1,zhujian1);
                preparedStatement.setString(2,user1);
                preparedStatement.setString(3,pass1);

                //4.执行语句、这个可以增删改，无返回值的语句
                preparedStatement.executeUpdate();

                //5.释放资源
                preparedStatement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("我猜是数据库地址写错了");
            }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("我猜是架包引用错了");
        }
    }
    @Test
    public void fangSQLzhuru()
    {
        zeng2("11","8","9");
        cha3("10");
    }
    //防SQL的查询,有输入参数
    public void cha3( String a1)
    {
        System.out.println("链接数据库");
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("1.加载");
            //2.链接数据库

            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
                System.out.println("2");
                //3.创建编译语句发送到数据库
                String a3= "select * from yonghubiao where zhujian=?";
                PreparedStatement preparedStatement = connection.prepareStatement(a3);
                System.out.println("3");
                //4.执行语句、这个可以（不能增删改）（查询），无返回值的语句
                preparedStatement.setString(1,a1);

                //下边的这个和上边不一样了
                ResultSet resultSet = preparedStatement.executeQuery();
                //解析结果
                while (resultSet.next())
                {
                    String zhujian = resultSet.getString("zhujian");
                    String user = resultSet.getString("user");
                    String pass = resultSet.getString("pass");
                    System.out.println("zhujian="+zhujian);
                    System.out.println("user="+user);
                    System.out.println("pass"+pass);
                }
                //5.释放资源
                resultSet.close();
                preparedStatement.close();
                connection.close();
                System.out.println("5");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("我猜是数据库地址写错了");
            }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("我猜是架包引用错了");
        }
    }

@Test
    public void   sql注入()
{
    cha1("10 or 1=1");
    System.out.println("-----------");
    cha3("10 or 1=1");

}
    //防SQL的查询,有输入参数，有返回参数
    public Product cha4( String a1)
    {
        Product product = new Product();
        System.out.println("链接数据库");
        //1.加载
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("1.加载");
            //2.链接数据库

            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/a", "root", "root");
                System.out.println("2");
                //3.创建编译语句发送到数据库
                String a3= "select * from yonghubiao where zhujian=?";
                PreparedStatement preparedStatement = connection.prepareStatement(a3);
                System.out.println("3");
                //4.执行语句、这个可以（不能增删改）（查询），无返回值的语句
                preparedStatement.setString(1,a1);

                //下边的这个和上边不一样了
                ResultSet resultSet = preparedStatement.executeQuery();
                //解析结果
                while (resultSet.next())
                {
                    String zhujian = resultSet.getString("zhujian");
                    String user = resultSet.getString("user");
                    String pass = resultSet.getString("pass");
                    System.out.println("zhujian="+zhujian);
                    System.out.println("user="+user);
                    System.out.println("pass"+pass);
                    //Product product = new Product();
                    //因为这条语句放在外边，下边的返回值才能收到，所以放到外边了
                    product.setZhujian(zhujian);
                    product.setPass(pass);
                    product.setUser(user);
                }
                //5.释放资源
                resultSet.close();
                preparedStatement.close();
                connection.close();
                System.out.println("5");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("我猜是数据库地址写错了");
            }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("我猜是架包引用错了");
        }

        return product;
    }
    @Test
    public void textcha5()
    {
        Product product = cha4("10");
        String zhujian = product.getZhujian();
        product.getUser();
        product.getPass();
        System.out.println("zhujian="+zhujian);
        String s = product.toString();
        System.out.println(s);
    }
    //0002,继承,这个需要看好几个java文件，我建3个文件，一个是fu，一个是zi1，一个是zi2

    private Integer id;
    private String name;
    private Integer age;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
    //003  static
    //静态方法，new一个对象是，可以直接用类名，
    //静态方法可以被静态方法和非静态方法调用
    //静态方法只能调用静态方法，不能调用非静态方法，只能用静态字段，详见zi1
    //加了stste的字段是共享的，测试方法，测试两个对象，第一个设置国家为中国，
    // 第二个设置为美国，如果后边的覆盖前边，那是共享的
    @Test
    public void  cc()
    {
        fu fu1 = new fu();
        fu fu2 = new fu();
        fu1.setA("中国");
        fu2.setA("美国");
        String a = fu1.getA();
        String a1 = fu2.getA();
        System.out.println("a="+a+"-----"+"b="+a1);
    }
    //构造代码块见a1
    @Test
    public void a12()
    {
        a1 a1 = new a1();
        a1 a2 = new a1();
        a1 a3 = new a1();
    }
    //接口,见a2,a3
    //讲业务层service，先定义接口，接口首大写,然后建立impl,
    // 里边引用servic接口创建的方法，然后这个方法，
    // 去调用dao层的接口里的方法，里边调用的参数是model里的
    //看不太懂Service和dao有什么区别，为什么分开
    //Service
    //dao,是增删改查
    //下边的项目是一个全新的购票系统
}