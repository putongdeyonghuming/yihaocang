package com.day01.station.service.impl;

import com.day01.station.dao.ProducrDao;
import com.day01.station.dao.impl.a3;
import com.day01.station.model.Product;
import com.day01.station.service.IProductService;

public class ProductService implements IProductService {
    a3 a3 = new a3();
    @Override
    //下边的这个方法是，传入一个参数进来，
    // 系统就保存这个参数对应的zhujian,user,pass了
    public void save(Product a) {
        //1.创建dao对象
        String zhujian = a.getZhujian();
        String user = a.getUser();
        String pass = a.getPass();
        //a3 a3 = new a3();把这行放到上边，可以让大家都调用
        a3.save(zhujian,user,pass);
        System.out.println(a.toString());
    }
    @Override
    public Product query(String a) {
        //查询a22，是主键的那一列是什么
        String a22="";
        Product query = a3.query(a22);
        return query;
    }
    @Override
    public void delect(String a) {

    }

    @Override
    public void update(Product a) {

    }


}
