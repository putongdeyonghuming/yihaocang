package com.day01.station.service;

import com.day01.station.model.Product;

public interface IProductService {
    public void save(Product a);
    public void delect(String a);
    public void update(Product a);
    public  Product query(String a);
}
