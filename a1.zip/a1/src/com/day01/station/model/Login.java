package com.day01.station.model;

public class Login {
    private Integer a;
    private String b;
    private Integer c;
    //默认的构造方法，一定要有这条，否则无法new对象
    public Login()
    {
        System.out.println("----------我是默认的构造方法----------");
    }


    public Login(Integer a, String b, Integer c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public Integer getA() {
        return a;
    }

    public void setA(Integer a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }

    public Integer getC() {
        return c;
    }

    public void setC(Integer c) {
        this.c = c;
    }

    @Override
    public String toString() {
        return "Login{" +
                "a=" + a +
                ", b='" + b + '\'' +
                ", c=" + c +
                '}';
    }
}
