package com.day01.station.model;

public class Product {
    //需要封装 private,另一个是Integer(类型 int)
    private String zhujian;
    private String user;
    private String pass;

    //提供get,set方法，alt+insert

    public String getZhujian() {
        return zhujian;
    }

    public void setZhujian(String zhujian) {
        this.zhujian = zhujian;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    //快捷键alt+insert
    @Override
    public String toString() {
        return "Product{" +
                "zhujian='" + zhujian + '\'' +
                ", user='" + user + '\'' +
                ", pass='" + pass + '\'' +
                '}';
    }
}
